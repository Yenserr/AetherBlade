using UnityEngine;

namespace AetherBlade
{
    /// <summary>
    /// Interfaz compartida por todo lo que puede recibir daño:
    /// héroe, enemigos, objetos destructibles, etc.
    /// </summary>
    public interface IDamageable
    {
        /// <param name="amount">Puntos de daño</param>
        /// <param name="sourcePosition">Posición de origen (para knockback)</param>
        void TakeDamage(int amount, Vector2 sourcePosition);
    }
}
