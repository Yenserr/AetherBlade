using UnityEngine;

namespace AetherBlade
{
    /// <summary>
    /// Suelo infinito simple: el suelo sigue la posición X de la cámara
    /// manteniéndose siempre centrado bajo el héroe.
    /// Adjuntar al objeto Ground.
    /// </summary>
    public class InfiniteGround : MonoBehaviour
    {
        [Header("Cámara")]
        [SerializeField] private Transform cameraTransform;

        [Header("Configuración")]
        [SerializeField] private float groundY = -2f;
        [SerializeField] private bool  lockY   = true;

        private void Start()
        {
            if (cameraTransform == null)
                cameraTransform = Camera.main.transform;

            // Hacer el suelo muy ancho para que nunca se vea el borde
            var sr = GetComponent<SpriteRenderer>();
            if (sr != null)
            {
                sr.drawMode = SpriteDrawMode.Tiled;
                sr.size = new Vector2(200f, sr.size.y);
            }

            // Collider igual de ancho
            var col = GetComponent<BoxCollider2D>();
            if (col != null)
                col.size = new Vector2(200f, col.size.y);
        }

        private void LateUpdate()
        {
            if (cameraTransform == null) return;

            // Seguir la X de la cámara para parecer infinito
            float newX = cameraTransform.position.x;
            float newY = lockY ? groundY : transform.position.y;
            transform.position = new Vector3(newX, newY, transform.position.z);
        }
    }
}
