using System.Collections;
using UnityEngine;

namespace AetherBlade
{
    /// <summary>
    /// Spawner que reaparece el monstruo después de que muere.
    /// Adjuntar a un GameObject vacío en la escena.
    /// </summary>
    public class MonsterSpawner : MonoBehaviour
    {
        [Header("Spawner")]
        [SerializeField] private GameObject monsterPrefab;
        [SerializeField] private float      respawnDelay  = 4f;
        [SerializeField] private Transform  spawnPoint;

        [Header("VFX")]
        [SerializeField] private ParticleSystem spawnVFX;

        private GameObject currentMonster;

        private void Start()
        {
            // Si ya hay un monstruo en escena, lo registramos
            if (currentMonster == null)
                SpawnMonster();
        }

        private void SpawnMonster()
        {
            Vector3 pos = spawnPoint != null ? spawnPoint.position : transform.position;

            if (spawnVFX != null)
            {
                spawnVFX.transform.position = pos;
                spawnVFX.Play();
            }

            currentMonster = Instantiate(monsterPrefab, pos, Quaternion.identity);

            // Escuchar cuando muere para respawnear
            var ai = currentMonster.GetComponent<ShadowMonsterAI>();
            if (ai != null)
                StartCoroutine(WatchMonster());
        }

        private IEnumerator WatchMonster()
        {
            // Esperar hasta que el monstruo sea destruido
            while (currentMonster != null)
                yield return new WaitForSeconds(0.5f);

            // Monstruo muerto — esperar y respawnear
            yield return new WaitForSeconds(respawnDelay);
            SpawnMonster();
        }
    }
}
